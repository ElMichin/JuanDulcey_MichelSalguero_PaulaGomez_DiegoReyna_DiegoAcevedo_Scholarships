package co.edu.unbosque.beans;

import java.util.ArrayList;

import co.edu.unbosque.controller.HttpClientSynchronous;
import jakarta.annotation.ManagedBean;
import jakarta.enterprise.context.RequestScoped;

@ManagedBean
@RequestScoped
public class LoginBean {

	private String id = "";
	private String name = "";
	private String username = "";
	private String password = "";
	private String country = "";
	private String city = "";
	private String email = "";

	public LoginBean() {
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void createUser() {
		HttpClientSynchronous.doPost("http://localhost:8081/user/createuser",
				"{ \"name\": \"" + name + "\",\"username\": \"" + username + "\",\"password\": \"" + password
						+ "\",\"country\": \"" + country + "\",\"city\": \"" + city + "\",\"email\": \"" + email
						+ "\"}");
	}

	public void showUser() {
		HttpClientSynchronous.doGet("http://localhost:8081/user/getall");
	}

	public void deleteByUsername() {
		HttpClientSynchronous.doDelete("http://localhost:8081/user/deletebynameuser?name=" + username);

	}

	public void updateUser() {
		HttpClientSynchronous.doPut("http://localhost:8081/user/updateuser?id=" + id, "{ \"name\": \"" + name + "\",\"username\": \"" + username + "\",\"password\": \"" + password
			+ "\",\"country\": \"" + country + "\",\"city\": \"" + city + "\",\"email\": \"" + email
			+ "\"}");
		
	}
}
